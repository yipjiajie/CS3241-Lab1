Name: Yip Jiajie
Matric Number: A0101924R
Email: a0101924@u.nus.edu

I am drawing a Disney "Tsum Tsum" character Pooh with a santa hat to add some festive element to it. 

Most of the shapes are drawn using GL_POLYGONS and the outlining are drawn using GL_LINE_STRIP.
Simple translations and rotations are used to get the right image.

Thank you and have a nice day!